//Rami Reddy Allugunti
//24016_167
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include"address_book.h"
int main()
{
    struct address_book details[1000];//creating structure array for addressbook for maximum of 1000 contacts
    int select=0;
    FILE *fptr;
    char str[100];
    fptr=fopen("data.csv","r");//creating file pointer to open csv file
    fgets(str,100,fptr);
    count=atoi(str+1);//we are using csv file to store data thats why we use "," as delimiter 
    for (int i = 0; i < count; i++)
    {
        fgets(str,100,fptr);//reading the string tokens for the values of structure array
        details[i].serial=atoi(strtok(str,","));
        strcpy(details[i].name,strtok(NULL,","));
        strcpy(details[i].mobile,strtok(NULL,","));
        strcpy(details[i].mail_id,strtok(NULL,","));
    }
    fclose(fptr);
    do 
    {
        printf("1.Create contact\n2.Search contact\n3.Edit contact\n4.Delete contact\n5.List the contact\n6.Exit\n");
        printf("Select the number between 1 to 6 :");
        scanf("%d",&select);
            if(select==1)
            {
                create(details);//if the user select 1 then perform create operation
                
            }
            if(select==2)
            {
                search(details);//if the user select 2 then perform search operation
            }
            if(select==3)
            {
                edit(details);//if the user select 3 then perform edit operation
            }
            if(select==4)
            {
                delete_data(details);//if the user select 4 then perform delete operation
            }
            if(select==5)
            {
                list(details);//if the user select 5 then perform list operation
            }
            if(select==6)//if user select 6 then store the structure array data into the file
            {
                
                FILE *fptr=fopen("data.csv","w");
                if(fptr==NULL){
                printf("Unable to open file for saving");
                exit(0);
                 }
                 fprintf(fptr,"#%d\n",count);
                for(int i=0;i<count;i++){
                fprintf(fptr,"%d,%s,%s,%s,\n",details[i].serial,details[i].name,details[i].mobile,details[i].mail_id);
                }
                fclose(fptr);
                break;
            }
            getchar();
    }while(select>=1&&select<=6);  
}
void create(struct address_book contact[])
{
    int flag=1;
    while(1)
    {
        printf("Enter name :");
        scanf(" %[^\n]",contact[count].name);
        if(my_isalpha(contact[count].name)==0)
        {
            printf("            ...Enter a valid name !...\n");
            continue;
        }
        else
        {
            break;
        }
    }
    while(1)
    {
        printf("Enter mobile number :");
        scanf(" %[^\n]",contact[count].mobile);
        if(valid_number(contact[count].mobile)==0)
        {
            printf("            ...please enter 10 digits !...\n");
            continue;
        }
        if(count==0)
        {
            break;
        }
        else if(number_cmp(contact)==0)
        {
            printf("            ...Enter unique number !...\n");
            continue;
        }
        break;
    }
    while(1)
    {
        printf("Enter mail id :");
        scanf(" %[^\n]",contact[count].mail_id);
        if(valid_mail(contact[count].mail_id)==0)
        {
            printf("            ...Enter valid mail !...\n");
            continue;
        }
        if(count==0)
        {
            break;
        }
        else if(email_cmp(contact)==0)
        {
            printf("            ...Enter unique Email id !...\n");
            continue;
        }
        else
        {   
            break;
        }
    }
    printf("\n            ...CONTACT CREATED !...\n");
    contact[count].serial=count+1;
    count++;

}
void search(struct address_book contact[])
{
    char str[30];
    int sel=0;
    if(count>0)
    {
    do
    {
        sel=select_search();
        //getchar();
    } while (!(sel>=1&&sel<=3));
    if(sel==1)
    {
        while(1)
        {
            printf("Enter name to search :");
            scanf(" %[^\n]",str);
            if(my_isalpha(str)==0)
            {
                printf("            ...Enter a valid name !...\n");
                continue;
            }
            break;
        }   
    }
    if(sel==2)
    {
        while(1)
        {
           printf("Enter number to search :");
           scanf(" %[^\n]",str);
           if(valid_number(str)==0)
            {
                printf("            ...please enter 10 digits !...\n");
                continue;
            }
            break;
        }       
    }
    if(sel==3)
    {
        while(1)
        {
        printf("Enter mail_id to search :");
        scanf(" %[^\n]",str);
        if(valid_mail(str)==0)
        {
            printf("            ...Enter correct Email id !...\n");
            continue;
        }
        break;
        }
    }
    n=search_found(contact,str,sel);
    if(n>0)
    {
    printf("\n            ...%d contacts found with your search...\n",n);
    printf("----------------------------------------------------------------------\n");
    printf("| %-8s%-15s%-13s%-30s |\n","S.NO","NAME","MOBILE NO","MAIL ID");
    printf("----------------------------------------------------------------------\n");
    for(int i=0;i<n;i++)
    {
        printf("| %-8d",contact[arr[i]].serial);
        printf("%-15s",contact[arr[i]].name);
        printf("%-13s",contact[arr[i]].mobile);
        printf("%-30s |\n",contact[arr[i]].mail_id);
    }
    printf("----------------------------------------------------------------------\n");
    }
    else
    {
        printf("\n            ...Entered data not match with contacts !...\n");
    }
    }
    else
    {
        printf("            ...There is no details in address book !...\n");
    }   
}
void edit(struct address_book contact[])
{
    while(1)
    {
        search(contact);
        if(count==0)
        {
            break;
        }
    if(n==0)
    {
        printf("enter correct choice\n");
        continue;
    }
    if(n==1)
    {
        edit_details(contact,ind);
        break;
    }
    if(n>1)
    {
        int choice=0;
        printf("1.re enter !\n2.select S.No\nselect between these 2\n");
        scanf("%d",&choice);
        if(choice==1)
        {
            continue;
        }
        else if(choice==2)
        {
            printf("Enter S.NO\n");
            scanf("%d",&ind);
        }
        else
        {
            printf("Enter correct choice\n");
            continue;
        }
        if(ind>count)
        {
            printf("         ...Serial number not match with contacts Serial numbers !...\n");
            break;
        }
        else
        {
            edit_details(contact,ind);
            printf("\n            ...Contact Edited Successfully !...\n");
            break;
        }
    }
    }
}
void delete_data(struct address_book contact[])
{
    while(1)
    {
        search(contact);
        if(count==0)
        {
            break;
        }
        if(n==0)
        {
        printf("enter correct choice\n");
        continue;
        }
        if(n==1)
        {
        struct address_book temp=contact[arr[ind-1]];
        contact[arr[ind-1]]=contact[count-1];
        contact[count-1]=temp;
        contact[arr[ind-1]].serial=contact[count-1].serial;
        count--;
        printf("            ...Contact Removed Successfully !...\n");
        break;
        }
        if(n>1)
        {
            int choice=0;
            printf("1.re enter !\n2.select S.No\nselect between these 2\n");
            scanf("%d",&choice);
            if(choice==1)
            {
                continue;
            }
            else if(choice==2)
            {
                printf("Enter S.NO\n");
                scanf("%d",&ind);
            }
            else
            {
                printf("Enter correct choice\n");
                continue;
            }
            struct address_book temp=contact[arr[ind-1]];
            contact[arr[ind-1]]=contact[count-1];
            contact[count-1]=temp;
            contact[arr[ind-1]].serial=contact[count-1].serial;
            count--;
            printf("            ...Contact Removed Successfully !...\n");
            break;    
        }
    }
}
void list(struct address_book contact[])
{
    if(count>0)
    {
    printf("\n              ...Here is the list of all contacts...\n");
    printf("----------------------------------------------------------------------\n");
    printf("| %-8s%-15s%-13s%-30s |\n","S.NO","NAME","MOBILE NO","MAIL ID");
    printf("----------------------------------------------------------------------\n");
    for(int i=0;i<count;i++)
    {
    printf("| %-8d%-15s%-13s%-30s |\n",contact[i].serial,contact[i].name,contact[i].mobile,contact[i].mail_id);
    }
    printf("----------------------------------------------------------------------\n");
    }
    else
    {
        printf("            ...There is no details in address book !...\n");
    }
}