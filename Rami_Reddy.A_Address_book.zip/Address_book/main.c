//Rami Reddy Allugunti
//24016_167
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include"address_book.h"
int count,n=0,ind=1;
int arr[200];//when common name found we will store the index of those in this array
int main()
{
    struct address_book details[1000];//creating structure array for addressbook for maximum of 1000 contacts
    int select=0;
    FILE *fptr;
    char str[100];
    fptr=fopen("data.csv","r");//creating file pointer to open csv file
    fgets(str,100,fptr);
    count=atoi(str+1);//we are using csv file to store data thats why we use "," as delimiter 
    for (int i = 0; i < count; i++)
    {
        fgets(str,100,fptr);//reading the string tokens for the values of structure array
        details[i].serial=atoi(strtok(str,","));
        strcpy(details[i].name,strtok(NULL,","));
        strcpy(details[i].mobile,strtok(NULL,","));
        strcpy(details[i].mail_id,strtok(NULL,","));
    }
    fclose(fptr);
    do 
    {
        printf("1.Create contact\n2.Search contact\n3.Edit contact\n4.Delete contact\n5.List the contact\n6.Exit\n");
        printf("Select the number between 1 to 6 :");
        scanf("%d",&select);
            if(select==1)
            {
                create(details);//if the user select 1 then perform create operation
                
            }
            if(select==2)
            {
                search(details);//if the user select 2 then perform search operation
            }
            if(select==3)
            {
                edit(details);//if the user select 3 then perform edit operation
            }
            if(select==4)
            {
                delete_data(details);//if the user select 4 then perform delete operation
            }
            if(select==5)
            {
                list(details);//if the user select 5 then perform list operation
            }
            if(select==6)//if user select 6 then store the structure array data into the file
            {
                
                FILE *fptr=fopen("data.csv","w");//open file
                if(fptr==NULL){
                printf("Unable to open file for saving");
                exit(0);
                }
                //to copy data into csv file
                fprintf(fptr,"#%d\n",count);
                for(int i=0;i<count;i++){
                fprintf(fptr,"%d,%s,%s,%s,\n",details[i].serial,details[i].name,details[i].mobile,details[i].mail_id);
                }
                fclose(fptr);
                break;
            }
            getchar();
    }while(select>=1&&select<=6);  
}
void create(struct address_book contact[])
{
    int flag=1;
    while(1)
    {
        //to check name is valid or not
        printf("Enter name :");
        scanf(" %[^\n]",contact[count].name);
        if(my_isalpha(contact[count].name)==0)
        {
            printf("            ...Enter a valid name !...\n");
            continue;
        }
        else
        {
            break;
        }
    }
    while(1)
    {

        printf("Enter mobile number :");
        scanf(" %[^\n]",contact[count].mobile);
        //to check number is valid or not
        if(valid_number(contact[count].mobile)==0)
        {
            printf("            ...please enter 10 digits !...\n");
            continue;
        }
        if(count==0)
        {
            break;
        }
        else if(number_cmp(contact)==0)
        {
            printf("            ...Enter unique number !...\n");
            continue;
        }
        break;
    }
    while(1)
    {
        printf("Enter mail id :");
        scanf(" %[^\n]",contact[count].mail_id);
        //to check email is valid or not
        if(valid_mail(contact[count].mail_id)==0)
        {
            printf("            ...Enter valid mail !...\n");
            continue;
        }
        if(count==0)
        {
            break;
        }
        else if(email_cmp(contact)==0)
        {
            printf("            ...Enter unique Email id !...\n");
            continue;
        }
        else
        {   
            break;
        }
    }
    printf("\n            ...CONTACT CREATED !...\n");
    contact[count].serial=count+1;//when the contact created then increment the count
    count++;

}
void search(struct address_book contact[])
{
    char str[30];
    int sel=0;
    if(count>0)//if count greater than 0 then perform search operation
    {
    do
    {
        sel=select_search();
        //getchar();
    } while (!(sel>=1&&sel<=3));
    if(sel==1)//when sel=1 then search name
    {
        while(1)
        {
            printf("Enter name to search :");
            scanf(" %[^\n]",str);
            if(my_isalpha(str)==0)
            {
                printf("            ...Enter a valid name !...\n");
                continue;
            }
            break;
        }   
    }
    if(sel==2)//when sel=2 then search mobile no
    {
        while(1)
        {
           printf("Enter number to search :");
           scanf(" %[^\n]",str);
           if(valid_number(str)==0)
            {
                printf("            ...please enter 10 digits !...\n");
                continue;
            }
            break;
        }       
    }
    if(sel==3)//when sel=3 then search email id
    {
        while(1)
        {
        printf("Enter mail_id to search :");
        scanf(" %[^\n]",str);
        if(valid_mail(str)==0)
        {
            printf("            ...Enter correct Email id !...\n");
            continue;
        }
        break;
        }
    }
    n=search_found(contact,str,sel);//when elements found then return the value into n
    if(n>0)//if details found then print details
    {
    printf("\n            ...%d contacts found with your search...\n",n);
    printf("----------------------------------------------------------------------\n");
    printf("| %-8s%-15s%-13s%-30s |\n","S.NO","NAME","MOBILE NO","MAIL ID");
    printf("----------------------------------------------------------------------\n");
    for(int i=0;i<n;i++)
    {
        printf("| %-8d",contact[arr[i]].serial);
        printf("%-15s",contact[arr[i]].name);
        printf("%-13s",contact[arr[i]].mobile);
        printf("%-30s |\n",contact[arr[i]].mail_id);
    }
    printf("----------------------------------------------------------------------\n");
    }
    else//if details not match then print this
    {
        printf("\n            ...Entered data not match with contacts !...\n");
    }
    }
    else//if count =0 then print this
    {
        printf("            ...There is no details in address book !...\n");
    }   
}
void edit(struct address_book contact[])
{
    while(1)
    {
        search(contact);//for searching
        if(count==0)
        {
            break;
        }
    if(n==0)
    {
        printf("enter correct choice\n");
        continue;
    }
    if(n==1)//if the search found then perform edit
    {
        edit_details(contact,ind);
        break;
    }
    if(n>1)//if more than 1 details found with entered details then perform this
    {
        int choice=0;
        printf("1.re enter !\n2.select S.No\nselect between these 2\n");
        scanf("%d",&choice);
        if(choice==1)//for re enter
        {
            continue;
        }
        else if(choice==2)//for selecting the s no of found data
        {
            printf("Enter S.NO\n");
            scanf("%d",&ind);
        }
        else
        {
            printf("Enter correct choice\n");
            continue;
        }
        if(ind>count)//if any other s no entered then print this
        {
            printf("         ...Serial number not match with contacts Serial numbers !...\n");
            break;
        }
        else
        {
            edit_details(contact,ind);
            printf("\n            ...Contact Edited Successfully !...\n");
            break;
        }
    }
    }
}
void delete_data(struct address_book contact[])
{
    while(1)
    {
        search(contact);//search for details
        if(count==0)
        {
            break;
        }
        if(n==0)
        {
        printf("enter correct choice\n");
        continue;
        }
        if(n==1)//if details found then delete it
        {
        struct address_book temp=contact[arr[ind-1]];
        contact[arr[ind-1]]=contact[count-1];
        contact[count-1]=temp;
        contact[arr[ind-1]].serial=contact[count-1].serial;
        count--;
        printf("            ...Contact Removed Successfully !...\n");
        break;
        }
        if(n>1)//if 2 or more details match with entered data then ask for choice
        {
            int choice=0;
            printf("1.re enter !\n2.select S.No\nselect between these 2\n");
            scanf("%d",&choice);
            if(choice==1)//for re enter the data 
            {
                continue;
            }
            else if(choice==2)//for selecting the s no to delete
            {
                printf("Enter S.NO\n");
                scanf("%d",&ind);
            }
            else
            {
                printf("Enter correct choice\n");
                continue;
            }
            //for deleting
            struct address_book temp=contact[arr[ind-1]];
            contact[arr[ind-1]]=contact[count-1];
            contact[count-1]=temp;
            contact[arr[ind-1]].serial=contact[count-1].serial;
            count--;
            printf("            ...Contact Removed Successfully !...\n");
            break;    
        }
    }
}
void list(struct address_book contact[])
{
    //if count >0 then print the details
    if(count>0)
    {
    printf("\n              ...Here is the list of all contacts...\n");
    printf("----------------------------------------------------------------------\n");
    printf("| %-8s%-15s%-13s%-30s |\n","S.NO","NAME","MOBILE NO","MAIL ID");
    printf("----------------------------------------------------------------------\n");
    for(int i=0;i<count;i++)
    {
    printf("| %-8d%-15s%-13s%-30s |\n",contact[i].serial,contact[i].name,contact[i].mobile,contact[i].mail_id);
    }
    printf("----------------------------------------------------------------------\n");
    }
    else//if there is no details the print
    {
        printf("            ...There is no details in address book !...\n");
    }
}