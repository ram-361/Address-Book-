#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include "address_book.h"
extern int count,ind;
extern int arr[200];
int my_isalpha(char a[])
{
    //for finding the string is alphabets or not
    int flag=1;
    for(int i=0;a[i]!='\0';i++)
    {
        if(!(a[i]<='z'&&a[i]>='a')||(a[i]<='Z'&&a[i]>='A'))
        {
            flag=0;//if any character in the string is not alphabet then return 0.
            break;
        }
    }
    return flag;
}
int my_isnum(char a[])
{
    int flag=1;
    //for finding string is numaric or not
    for(int i=0;a[i]!='\0';i++)
    {
        if(!(a[i]>='0'&&a[i]<='9'))
        {
            flag=0;//if any character in the string is not numaric value then it return 0.
            break;
        }
    }
    return flag;
}
int number_cmp(struct address_book a[])
{
    //for comparing the entered number with details
    for(int i=0;i<count;i++)
    {
        if (strcmp(a[i].mobile,a[count].mobile)==0)
        {
            return 0;
        }
        
    }
    return 1;
}
int email_cmp(struct address_book a[])
{
    //for comparing entered email id with details
    for(int i=0;i<count;i++)
    {
        if (strcmp(a[i].mail_id,a[count].mail_id)==0)
        {
            return 0;
        }
        
    }
    return 1;
}
int valid_number(char str[])
{
    //is the number is valid or not
    if(my_isnum(str)==0)
    {
        return 0;
    }
    if(strlen(str)!=10)
    {
        return 0;
    }
    
}
int valid_mail(char str[])
{
    //is the email id is valid or
    if(strchr(str,' ')!=NULL)
        {
            return 0;
        }
        for(char i='A';i<='Z';i++)
        {
        if(strchr(str,i)!=NULL)
        {
            return 0;
        }
        }
        char *c=strchr(str,'@');
        if(c!=NULL)
        {
            if(!(isalpha(*(c+1))||isdigit(*(c+1))&&isalpha(*(c-1))||isdigit(*(c-1))))
            {
                
                return 0;
            }
        }
        else
        {
            return 0;
        }
        int l=strlen(str);
        if(!(strstr((str+l-4),".com")))
        {
            return 0;
        }
}
int select_search()
{ 
    //for selecting 
    int sel=0;
    do
    {
        printf("1.search by name :\n2.search by mobile :\n3.search by mail_id :\nselect between those 3.\n");
        scanf("%d",&sel);
        getchar();
    } while (!(sel>=1&&sel<=3));
    return sel;
}
int search_found(struct address_book a[],char *str,int sel)
{
    int c=0;
    //for comparing the entered string with details 
    for(int i=0;i<count;i++)
    {
        if(sel==1)
        {
            //if found then store the index of that into arr and increment the found count
        if(strcmp(a[i].name,str)==0)
        {
            arr[c++]=i;
        }}
        if(sel==2)
        {
        if(strcmp(a[i].mobile,str)==0)
        {
            arr[c++]=i;
        }}
        if(sel==3)
        {
        if(strcmp(a[i].mail_id,str)==0)
        {
            arr[c++]=i;
        }}
    }
    return c;//return the found count 
}
int select_edit()
{   //delect for editing
    int sel=0;
    do
    {
        printf("1.edit name :\n2.edit mobile :\n3.edit mail_id :\nselect between those 3.\n");
        scanf("%d",&sel);
        getchar();
    } while (!(sel>=1&&sel<=3));
    return sel;
}
void edit_details(struct address_book a[],int ind)
{
    char str[30];
        int sel=0;
    do
    {
        sel=select_edit();
    } while (!(sel>=1&&sel<=3));
    //if sel=1 then string will edited with names of the details
    if(sel==1)
    {
        while(1)
        {
            printf("Enter name :");
            scanf(" %[^\n]",str);
            if(my_isalpha(str)==0)
            {
                printf("            ...Enter a valid name !...\n");
                continue;
            }
            break;
        }
        for(int j=0;j<20;j++)
        {
        a[arr[ind-1]].name[j]=str[j];
        }
    }
    //if sel=2 then string edited with mobile no of details
    if(sel==2)
    {
        while(1)
        {
           printf("Enter number  :");
           scanf(" %[^\n]",str);
           strcpy(a[count].mobile,str);
           if(valid_number(str)==0)
            {
                printf("            ...please enter 10 digits !...\n");
                continue;
            }
            if(number_cmp(a)==0)
            {
                printf("            ...Enter unique number !...\n");
                continue;
            }
            break;
        }
        for(int j=0;j<11;j++)
        {
        a[arr[ind-1]].mobile[j]=str[j];
        }
    }
    //if sel=3 then entered string edited with email id
    if(sel==3)
    {
        while(1)
        {
        printf("Enter mail_id to search :");
        scanf(" %[^\n]",str);
        strcpy(a[count].mail_id,str);
        if(valid_mail(str)==0)
        {
            printf("            ...Enter valid mail !...\n");
            continue;
        }
        if(email_cmp(a)==0)
        {
            printf("            ...Enter unique Email id !...\n");
            continue;
        }
        break;
        }
        for(int j=0;j<30;j++)
        {
        a[arr[ind-1]].mail_id[j]=str[j];
        }
    }

}



