struct address_book
{
    char name[20];
    char mobile[11];
    char mail_id[30];
    int serial;
    
};
void create(struct address_book contact,FILE *fp);
int search(struct address_book contact,FILE *fp);
void edit(struct address_book contact,FILE *fp);
void delete(struct address_book contact,FILE *fp);
void list(struct address_book contact,FILE *fp);
int my_isalpha(char a[]);
int my_isnum(char a[]);
int number_cmp(struct address_book a,FILE *fp,char *str);
int mail_cmp(struct address_book a,FILE *fp,char *str);
int valid_number(char str[]);
int valid_mail(char contact[]);
int select_search();
void search_found(struct address_book a,char *str,int sel,FILE *fp);
void print_searchfound(struct address_book a,char *str,int sel,FILE *fp);
int select_edit();
void edit_details(struct address_book contact,FILE *fp);
void edit_details1(struct address_book contact,FILE *fp,int n);
void delete_details(FILE *fp);
int count,n=0;
long int pos=0;
