struct address_book
{
    char name[20];
    char mobile[11];
    char mail_id[30];
    int serial;
};
void create(struct address_book contact[]);
void search(struct address_book contact[]);
void edit(struct address_book contact[]);
void delete_data(struct address_book contact[]);
void list(struct address_book contact[]);
int my_isalpha(char a[]);
int my_isnum(char a[]);
int number_cmp(struct address_book a[]);
int email_cmp(struct address_book a[]);
int valid_number(char str[]);
int valid_mail(char contact[]);
int search_found(struct address_book a[],char *str,int sel);
int select_search();
int select_edit();
void edit_details(struct address_book contact[],int ind);
int count,n=0,ind=1;;
int arr[200];